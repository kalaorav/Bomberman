<?xml version="1.0" encoding="UTF-8"?>
<tileset name="64x" tilewidth="64" tileheight="64">
 <tile id="0">
  <image width="64" height="64" source="data/tileset/Bark.png"/>
 </tile>
 <tile id="1">
  <image width="64" height="64" source="data/tileset/bookshelf.png"/>
 </tile>
 <tile id="2">
  <image width="64" height="64" source="data/tileset/BrickOv.png"/>
 </tile>
 <tile id="3">
  <image width="64" height="64" source="data/tileset/Bricks.png"/>
 </tile>
 <tile id="4">
  <image width="64" height="64" source="data/tileset/Coal.png"/>
 </tile>
 <tile id="5">
  <image width="64" height="64" source="data/tileset/CrackOver.png"/>
 </tile>
 <tile id="6">
  <image width="64" height="64" source="data/tileset/CrateOver.png"/>
 </tile>
 <tile id="7">
  <image width="64" height="64" source="data/tileset/Dirt.png"/>
 </tile>
 <tile id="8">
  <image width="64" height="64" source="data/tileset/GemOv1.png"/>
 </tile>
 <tile id="9">
  <image width="64" height="64" source="data/tileset/GemOv2.png"/>
 </tile>
 <tile id="10">
  <image width="64" height="64" source="data/tileset/GemOv3.png"/>
 </tile>
 <tile id="11">
  <image width="64" height="64" source="data/tileset/GemOv4.png"/>
 </tile>
 <tile id="12">
  <image width="64" height="64" source="data/tileset/Glass.png"/>
 </tile>
 <tile id="13">
  <image width="64" height="64" source="data/tileset/GlassFacete.png"/>
 </tile>
 <tile id="14">
  <image width="64" height="64" source="data/tileset/Gold0.png"/>
 </tile>
 <tile id="15">
  <image width="64" height="64" source="data/tileset/Gold1.png"/>
 </tile>
 <tile id="16">
  <image width="64" height="64" source="data/tileset/Grass.png"/>
 </tile>
 <tile id="17">
  <image width="64" height="64" source="data/tileset/Gravel.png"/>
 </tile>
 <tile id="18">
  <image width="64" height="64" source="data/tileset/Ice.png"/>
 </tile>
 <tile id="19">
  <image width="64" height="64" source="data/tileset/Iron.png"/>
 </tile>
 <tile id="20">
  <image width="64" height="64" source="data/tileset/LavaF1.png"/>
 </tile>
 <tile id="21">
  <image width="64" height="64" source="data/tileset/LavaF2.png"/>
 </tile>
 <tile id="22">
  <image width="64" height="64" source="data/tileset/LavaF3.png"/>
 </tile>
 <tile id="23">
  <image width="64" height="64" source="data/tileset/LavaF4.png"/>
 </tile>
 <tile id="24">
  <image width="64" height="64" source="data/tileset/LeavesOP.png"/>
 </tile>
 <tile id="25">
  <image width="64" height="64" source="data/tileset/LeavesTS.png"/>
 </tile>
 <tile id="26">
  <image width="64" height="64" source="data/tileset/MossOver.png"/>
 </tile>
 <tile id="27">
  <image width="64" height="64" source="data/tileset/Mud.png"/>
 </tile>
 <tile id="28">
  <image width="64" height="64" source="data/tileset/OreVein.png"/>
 </tile>
 <tile id="29">
  <image width="64" height="64" source="data/tileset/Planks.png"/>
 </tile>
 <tile id="30">
  <image width="64" height="64" source="data/tileset/Sand.png"/>
 </tile>
 <tile id="31">
  <image width="64" height="64" source="data/tileset/SmoothStone.png"/>
 </tile>
 <tile id="32">
  <image width="64" height="64" source="data/tileset/Stone.png"/>
 </tile>
 <tile id="33">
  <image width="64" height="64" source="data/tileset/TilledSoil.png"/>
 </tile>
 <tile id="34">
  <image width="64" height="64" source="data/tileset/TreeRings.png"/>
 </tile>
 <tile id="35">
  <image width="64" height="64" source="data/tileset/WalkStone.png"/>
 </tile>
 <tile id="36">
  <image width="64" height="64" source="data/tileset/WaterF1.png"/>
 </tile>
 <tile id="37">
  <image width="64" height="64" source="data/tileset/WaterF2.png"/>
 </tile>
 <tile id="38">
  <image width="64" height="64" source="data/tileset/WaterF3.png"/>
 </tile>
 <tile id="39">
  <image width="64" height="64" source="data/tileset/WaterF4.png"/>
 </tile>
 <tile id="40">
  <image width="64" height="64" source="data/tileset/WoolSnow.png"/>
 </tile>
</tileset>
