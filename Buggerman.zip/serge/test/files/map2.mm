<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<<<<<<<<<<<<<node CREATED="1324705885987" ID="ID_1225132521" MODIFIED="1324705885987" TEXT="New Mindmap">
<node CREATED="1324705896617" ID="ID_617655190" MODIFIED="1324744730640" POSITION="right" TEXT="Bomb Shop">
<node CREATED="1324705902890" ID="ID_1056130361" MODIFIED="1324705976631" TEXT="Initial Visit">
<node CREATED="1324705907458" ID="ID_1153951132" MODIFIED="1324705912968" TEXT="Hello is this your first time">
<node CREATED="1324705916594" ID="ID_1841290260" MODIFIED="1324705917928" TEXT="Yes">
<node CREATED="1324705922115" ID="ID_1036158059" MODIFIED="1324706957125" TEXT="Ok, good what would you like to do">
<arrowlink DESTINATION="ID_184817469" ENDARROW="Default" ENDINCLINATION="277;0;" ID="Arrow_ID_1094481857" STARTARROW="None" STARTINCLINATION="277;0;"/>
<node CREATED="1324705954684" ID="ID_1569350459" MODIFIED="1324706049701" TEXT="Buy"/>
<node CREATED="1324705960628" ID="ID_15138829" MODIFIED="1324705961658" TEXT="Leave"/>
</node>
</node>
<node CREATED="1324705918587" ID="ID_958409763" MODIFIED="1324705920073" TEXT="No">
<node CREATED="1324705938507" ID="ID_1182817826" MODIFIED="1324706970691" TEXT="Ok, well, my mistake">
<arrowlink DESTINATION="ID_184817469" ENDARROW="Default" ENDINCLINATION="198;0;" ID="Arrow_ID_1655850319" STARTARROW="None" STARTINCLINATION="198;0;"/>
<node CREATED="1324705948292" ID="ID_1221045743" LINK="#ID_1141789581" MODIFIED="1324706086036" TEXT="Buy"/>
<node CREATED="1324705950083" ID="ID_97541306" MODIFIED="1324705951818" TEXT="Leave"/>
</node>
</node>
</node>
</node>
<node CREATED="1324705968668" ID="ID_497180817" MODIFIED="1324707208156" TEXT="Subsequent visits">
<node CREATED="1324705982365" HGAP="66" ID="ID_184817469" MODIFIED="1324745040566" TEXT="That will be 50$ for 4 ok?" VSHIFT="65">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Some long text.
    </p>
    <p>
      With multiple lines
    </p>
    <p>
      and stuff
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1324705991021" ID="ID_313710096" MODIFIED="1324705992723" TEXT="Buy">
<node CREATED="1324705995829" ID="ID_1141789581" MODIFIED="1324705999931" TEXT="Ok, they are yours"/>
</node>
<node CREATED="1324705993253" ID="ID_1580224594" MODIFIED="1324705994787" TEXT="Leave">
<node CREATED="1324706002773" ID="ID_1370379106" MODIFIED="1324706007379" TEXT="No worries, come back soon"/>
</node>
</node>
</node>
</node>
<node CREATED="1324744942226" ID="ID_297792714" MODIFIED="1324744946259" POSITION="left" TEXT="Other Place">
<node CREATED="1324744947474" ID="ID_1442983591" MODIFIED="1324745070132" TEXT="Do you want to tango">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      $one-variable = 1
    </p>
    <p>
      $two-variable = 2
    </p>
    <p>
      Lots of multiple line text
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1324744955195" ID="ID_317216859" MODIFIED="1324745004775" TEXT="yes">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      $do-tango = True
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1324744958603" ID="ID_279007489" MODIFIED="1324745021563" TEXT="no">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      $do-tango = False
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
</map>
