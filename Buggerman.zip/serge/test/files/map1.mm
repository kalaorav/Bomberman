<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1324705885987" ID="ID_1225132521" MODIFIED="1326081582992" TEXT="New Mindmap">
<node CREATED="1324705896617" ID="ID_617655190" MODIFIED="1324744730640" POSITION="right" TEXT="Bomb Shop">
<node CREATED="1324705902890" ID="ID_1056130361" MODIFIED="1324935694422" TEXT="Initial Visit">
<node CREATED="1324705907458" ID="ID_1153951132" MODIFIED="1324705912968" TEXT="Hello is this your first time">
<node CREATED="1324705916594" ID="ID_1841290260" MODIFIED="1324705917928" TEXT="Yes">
<node CREATED="1324705922115" ID="ID_1036158059" MODIFIED="1324746349498" TEXT="Ok, good what would you like to do">
<node CREATED="1324705954684" ID="ID_1569350459" MODIFIED="1324746367538" TEXT="Buy">
<arrowlink DESTINATION="ID_1141789581" ENDARROW="Default" ENDINCLINATION="203;0;" ID="Arrow_ID_1991416982" STARTARROW="None" STARTINCLINATION="203;0;"/>
</node>
<node CREATED="1324705960628" ID="ID_15138829" MODIFIED="1324705961658" TEXT="Leave"/>
</node>
</node>
<node CREATED="1324705918587" ID="ID_958409763" MODIFIED="1324705920073" TEXT="No">
<node CREATED="1324705938507" ID="ID_1182817826" MODIFIED="1324746347178" TEXT="Ok, well, my mistake">
<node CREATED="1324705948292" ID="ID_1221045743" LINK="#ID_1141789581" MODIFIED="1324706086036" TEXT="Buy"/>
<node CREATED="1324705950083" ID="ID_97541306" MODIFIED="1324705951818" TEXT="Leave"/>
</node>
</node>
</node>
</node>
<node CREATED="1324705968668" ID="ID_497180817" MODIFIED="1324707208156" TEXT="Subsequent visits">
<node CREATED="1324705982365" HGAP="66" ID="ID_184817469" MODIFIED="1324748214910" TEXT="That will be 50$ for 4 ok?" VSHIFT="65">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Some long text.
    </p>
    <p>
      With multiple lines
    </p>
    <p>
      and stuff
    </p>
  </body>
</html></richcontent>
<node CREATED="1324705991021" ID="ID_313710096" MODIFIED="1324705992723" TEXT="Buy">
<node CREATED="1324705995829" ID="ID_1141789581" MODIFIED="1324746421407" TEXT="Ok, they are yours"/>
</node>
<node CREATED="1324705993253" ID="ID_1580224594" MODIFIED="1324750610039" TEXT="Leave">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      $callback = 'the-way-ahead'
    </p>
  </body>
</html></richcontent>
<node CREATED="1324706002773" ID="ID_1370379106" MODIFIED="1324746735286" TEXT="No worries, come back soon"/>
</node>
</node>
</node>
</node>
<node CREATED="1324744942226" ID="ID_297792714" MODIFIED="1324744946259" POSITION="left" TEXT="Other Place">
<node CREATED="1324744947474" FOLDED="true" ID="ID_1442983591" MODIFIED="1324937315799" TEXT="Do you want to tango">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      $a=123
    </p>
  </body>
</html></richcontent>
<node CREATED="1324744955195" ID="ID_317216859" MODIFIED="1324745004775" TEXT="yes">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      $do-tango = True
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1324744958603" ID="ID_279007489" MODIFIED="1324745021563" TEXT="no">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      $do-tango = False
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node CREATED="1324746829944" ID="ID_990728829" MODIFIED="1324938632452" POSITION="right" TEXT="Dupe1">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      $return-to = me
    </p>
  </body>
</html></richcontent>
<node CREATED="1324746834624" ID="ID_1202922704" MODIFIED="1324746838350" TEXT="How are you">
<node CREATED="1324746846688" ID="ID_764922498" MODIFIED="1324746847821" TEXT="Ok"/>
<node CREATED="1324746848360" ID="ID_249870573" MODIFIED="1324746849334" TEXT="Fine"/>
</node>
</node>
<node CREATED="1324746850616" ID="ID_772240581" MODIFIED="1324936942340" POSITION="right" TEXT="Dupe2">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      $return-to = 'Dupe1'
    </p>
  </body>
</html></richcontent>
<node CREATED="1324746854944" ID="ID_754950400" MODIFIED="1324746858096" TEXT="How are you">
<node CREATED="1324746858656" ID="ID_924675072" MODIFIED="1324746859998" TEXT="Bad"/>
<node CREATED="1324746860745" ID="ID_1621985688" MODIFIED="1324746862222" TEXT="Worse"/>
</node>
</node>
<node CREATED="1324939757183" ID="ID_1239809539" MODIFIED="1324939912287" POSITION="right" TEXT="Ending">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      
    </p>
    <p>
      $return-to = me
    </p>
  </body>
</html></richcontent>
<node CREATED="1324939763894" ID="ID_376936730" MODIFIED="1324939768356" TEXT="Good?">
<node CREATED="1324939768974" ID="ID_316330597" MODIFIED="1324939770476" TEXT="Yep">
<node CREATED="1324939778878" ID="ID_100502478" MODIFIED="1324939780060" TEXT="Well"/>
</node>
<node CREATED="1324939771030" ID="ID_1085708781" MODIFIED="1324939772534" TEXT="Nope">
<node CREATED="1324939773518" ID="ID_1934028716" MODIFIED="1324939775356" TEXT="Ok then"/>
</node>
</node>
</node>
<node CREATED="1326081584388" ID="ID_1471092099" MODIFIED="1326081587498" POSITION="left" TEXT="Conditionals">
<node CREATED="1326081588652" ID="ID_676460047" MODIFIED="1326085006212" TEXT="setting branch">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      $return-to = me
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1326081635646" ID="ID_1125385247" MODIFIED="1326081640396" TEXT="do you want to be ready">
<node CREATED="1326081641470" ID="ID_237404636" MODIFIED="1326084975667" TEXT="yes">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      $ready = 'True'
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1326081643142" ID="ID_905052436" MODIFIED="1326081644067" TEXT="no"/>
</node>
</node>
<node CREATED="1326081804003" ID="ID_146252006" MODIFIED="1326081812971" TEXT="Finished branch"/>
<node CREATED="1326082904016" ID="ID_555110703" MODIFIED="1326082950976" TEXT="Wait for complete">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      $return-to = me
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1326081596133" ID="ID_1305263565" MODIFIED="1326082944075" TEXT="waiting branch">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      $case = 'ready'
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1326081607413" ID="ID_551854247" MODIFIED="1326081785025" TEXT="False">
<node CREATED="1326081621669" ID="ID_541952425" MODIFIED="1326081625011" TEXT="You are not ready yet"/>
</node>
<node CREATED="1326081619517" ID="ID_1647474923" MODIFIED="1326081781176" TEXT="True">
<node CREATED="1326081627998" ID="ID_1536990740" MODIFIED="1326081632923" TEXT="congratulations, you are ready"/>
</node>
</node>
</node>
</node>
</node>
</map>
