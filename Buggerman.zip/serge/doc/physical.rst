Physical
========

.. contents::

.. py:module:: physical


PhysicalConditions
------------------

.. inheritance-diagram:: serge.physical.PhysicalConditions

.. autoclass:: serge.physical.PhysicalConditions
    :show-inheritance:
    :members:
    
    
PhysicalBody
------------

.. inheritance-diagram:: serge.physical.PhysicalBody

.. autoclass:: serge.physical.PhysicalBody
    :show-inheritance:
    :members:
