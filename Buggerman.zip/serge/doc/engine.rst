Engine
======

.. contents::
.. py:module:: engine
   

Engine
------
    
.. autoclass:: serge.engine.Engine
    :show-inheritance:
    :members:
    
    
EngineStats
-----------

.. autoclass:: serge.engine.EngineStats
    :members:
    
    
