"""Common elements"""

import pygame
import os
import sys

import serge.engine
import serge.common
import serge.blocks.scores

log = serge.common.getLogger('Game')
from theme import G

version = '0.0.1' 

#
# Events
#
# Put events here with names E_MY_EVENT
# and they will be registered automatically
#
# E_GAME_STARTED = 'game-started'
