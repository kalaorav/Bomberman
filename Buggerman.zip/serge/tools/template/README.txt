%(name)s
%(under)s



Requires: Python 2.6+, pygame 1.9+ and pymunk

To run the game:

    python %(name_lower)s.py
    

Thanks for playing!

What's new
----------
